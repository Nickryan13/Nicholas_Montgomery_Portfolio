# [YouTube Tutorial](https://www.youtube.com/playlist?list=PL3KAvm6JMiowqFTXj3oPQkhP7aCgRHFTm)
I created a Youtube code along tutorial for this project. Click the link above to view!

# react-portfolio-starter
A React based personal portfolio app using create-react-app and React Router v4.

# Tools
* create-react-app cli
* React MDL material design
* React Router v4

# Start App
Clone repo, install, cd into folder and run:
```git
npm install
npm start
```
